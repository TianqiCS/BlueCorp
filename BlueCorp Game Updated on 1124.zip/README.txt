The Blu Team

Members: Alden, Bella, Emily, Felipe, Tianqi, and Hope

To play the game, simply open the BluCorp.html file with Google Chrome!

Hope you enjoy!!!


Notice: The game files are updated, you should not use the old game resources files

Demo: BluCorp.html
Archive: BlueCorp Game Archive 1124.html